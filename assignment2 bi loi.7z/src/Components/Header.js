
import React, { Component } from 'react';
import "../App.css";
import { Collapse, Navbar, NavbarToggler, NavbarBrand, Nav, NavItem} from 'reactstrap';
import {  Link, NavLink  } from 'react-router-dom'


class Header extends Component {
  constructor(props) {
    super(props);

    this.toggle = this.toggle.bind(this);
    this.state = {
      isOpen: false
    };
  }
  toggle() {
    this.setState({
      isOpen: !this.state.isOpen
    });
  }
  render() {
    return (
      
        <div >
          
        <Navbar container dark light expand="md">
          
          <NavbarBrand href="/"><img src="https://i.pinimg.com/474x/5f/26/fb/5f26fb23871a37d558b5d06700340444--logo-social-social-business.jpg" alt="app nhân sự" width="50" height="50" /></NavbarBrand>
          <NavbarToggler onClick={this.toggle} />
          <Collapse isOpen={this.state.isOpen} navbar>
            <Nav>
              
              <NavItem className='m-2 text-light'>
              <NavLink  to="/nhansu" activeClassName="selected">
              <i class="fa fa-users fa-lg"></i>Nhân Viên
                </NavLink>
                </NavItem >
                <NavItem  className='m-2'>
                <NavLink to="/phongban" activeClassName="selected">
              <i class="fa fa-address-card fa-lg"></i>Phòng Ban
                </NavLink>
                </NavItem>
                <NavItem  className='m-2'>
                <NavLink to="/bangluong" activeClassName="selected">
              <i class="fa fa-money fa-lg"></i>Bảng Lương
                </NavLink>
              </NavItem>      
                   
            </Nav>
          </Collapse>
          
        </Navbar>
        
        </div>
      
    );
  }
}
export default Header;

// import React, { Component } from 'react';
// import { Navbar, NavbarBrand, Nav, NavbarToggler, NavItem, NavLink, Collapse, Jumbotron } from 'reactstrap';
// // import { NavLink } from 'react-router-dom'; 

// class Header extends Component {

//     constructor(props){
//         super(props);


        
//         this.state ={
//             isNavOpen: false
//         };
//         this.toggleNav = this.toggleNav.bind(this);
        
//     }

//     toggleNav(){
//         this.setState({
//             isNavOpen: !this.state.isNavOpen
//         });
//     }
//     render(){
//         return(
//             <React.Fragment>
//             <Navbar dark expand="md">
//                     <div className="container">
//                         <NavbarToggler onClick={this.toggleNav} />
//                         <NavbarBrand className="mr-auto" href="/"><img src='assets/images/logo.png' height="30" width="41" alt='Ristorante Con Fusion' />
//                         </NavbarBrand>
//                         <Collapse isOpen={this.state.isNavOpen} navbar>
//                             <Nav navbar>
//                             <NavItem>
//                                 <NavLink className="nav-link"  href='/home'><span className="fa fa-home fa-lg"></span> Home</NavLink>
//                             </NavItem>
//                             <NavItem>
//                                 <NavLink className="nav-link" href='/aboutus'><span className="fa fa-info fa-lg"></span> About Us</NavLink>
//                             </NavItem>
//                             <NavItem>
//                                 <NavLink className="nav-link"  href='/menu'><span className="fa fa-list fa-lg"></span> Menu</NavLink>
//                             </NavItem>
//                             <NavItem>
//                                 <NavLink className="nav-link" href='/contactus'><span className="fa fa-address-card fa-lg"></span> Contact Us</NavLink>
//                             </NavItem>
//                             </Nav>
//                         </Collapse>
//                     </div>
//                 </Navbar>
                
//             </React.Fragment>
//         );
//     }
// }


// export default Header;