import React from "react";
import { Breadcrumb, BreadcrumbItem, Card, CardImg, CardText, CardBody, CardTitle } from "reactstrap";
import { Link } from 'react-router-dom';



function RenderImg({staff}){
    return(
        <div className="col-12 col-md-5 m-1">
            
                <img width="100%" src={staff.image}  alt={staff.name} />
                        
                </div>   
            );
        }
            
function RenderTtnv({staff}) {
    return(
        <div>
            <h2>Họ và Tên: {staff.name}</h2>
            <p>Ngày sinh: {staff.doB}</p>
            <p>Ngày vào công ty: {staff.startDate}</p>
            <p>Phòng ban: {staff.department}</p>
            <p>Số ngày nghỉ còn lại: {staff.annualLeave}</p>
            <p>Số ngày làm thêm: {staff.overTime}</p>
        </div>
    )
}

const StaffDetail = (props) => {
    if (props.dish != null) {
        return (
            <div className="container">
            <div className="row">
                <Breadcrumb>

                    <BreadcrumbItem><Link to="/nhansu">Nhân Viên</Link></BreadcrumbItem>
                    <BreadcrumbItem active>{props.staff.name}</BreadcrumbItem>
                </Breadcrumb>
                <div className="col-12">
                    <h3>{props.dish.name}</h3>
                    <hr />
                </div>                
            </div>
            <div className="row"> 
                
                    <RenderImg dish={props.staff} />
                    
                
                     <RenderTtnv comments={ props.staff} />
                     
                
            
            </div>
            </div>
        );
    }
    
    else
        return(
            <div> </div>
        )

    

    
}


export default StaffDetail;


