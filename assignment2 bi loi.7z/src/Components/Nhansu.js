import React from "react";
import { Card, CardImg, CardText, Breadcrumb, BreadcrumbItem } from 'reactstrap'
import { Link } from 'react-router-dom';



function RenderStaff({staff}) {
    return(
        <div>
            <Card>
            <Link to={`/nhansu/${staff.id}`}>
                <CardImg width="100%" src={staff.img} alt={staff.name} />
                <CardText>{staff.name}</CardText>
                </Link>
            </Card>
        </div>
    )
}
 const Staffs = (props) => {
     const staff = props.staffs.map((staff) =>{
         return(
             <div key={staff.id} className="col-12 col-md-5 m-1">
                 <RenderStaff staff={staff} />
             </div>
         )
     })

     return(
        <div className="container">
        <div className="row">
            <Breadcrumb>
                <BreadcrumbItem>
                    <Link to='/home'>Home</Link>
                </BreadcrumbItem>
                <BreadcrumbItem active>Nhân Sự</BreadcrumbItem>
            </Breadcrumb>
            <div className="col-12">
                <h3>Nhân Sự</h3>
                <hr />
            </div>
        </div>
        <div className="row">
            { staff }
        </div>

    </div>
     )
 }

 export default Staffs;
