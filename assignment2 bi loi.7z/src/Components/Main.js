import React, { Component } from 'react';
// import logo from './logo.svg';
import Header from './Header';
import Footer from './Footer';
import Staffs from './Nhansu';
import Phongban from './Phongban';
import Bangluong from './Bangluong';
import StaffDetail from './Thongtinnv';
import {
  BrowserRouter,
  Switch,
  Route,
  Link
} from "react-router-dom";
import { STAFFS } from '../shares/staffs'
import '../App.css';





class Main extends Component{

  constructor(props) {
    super(props)
    this.state = {
        staffs: STAFFS,
        selectStaff: null,
        columSet: "col-sm-12 col-md-4 col-lg-2 pb-2 pt-2 text-center",
    }
}

  
  render() {

    
  return (
    <div>
      
      <Header />
      {/* <BrowserRouter>
      <Switch>
          <Route exact path="/Nhansu" component={() => <Staffs staffs={this.state.staffs} />} />
          
          <Route path="/Phongban">
            <Phongban />
          </Route>
          <Route path="/Bangluong">
            <Bangluong />
          </Route>
          <Route path={`/nhansu/${staff.id}`}>
            <Bangluong />
          </Route>
          
          
          
        </Switch>
        </BrowserRouter> */}
        <Footer />
    </div>
  );
}
}







export default Main;
