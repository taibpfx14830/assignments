import React from 'react';
// import logo from './logo.svg';
import Main from './Components/Main';
import './App.css';

function App() {
  return (
    <div className="App">
      <Main />
    </div>
  );
}

export default App;
